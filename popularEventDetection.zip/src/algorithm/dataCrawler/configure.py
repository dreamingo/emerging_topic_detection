# -- coding: utf-8 --

APP_KEY = "245283018"

APP_SECRET = "ef354980fddd9d6b78d9df1590ded3b4"

CALLBACK_URL = "https://api.weibo.com/oauth2/default.html"

ACCOUNT="YOUR WEIBO ACCOUNT"

PASSWORD="YOUR PASSWORD"

COOKIE_FILE = "weibo_login_cookies.dat"

APP_COUNT = 10

DEBUG = True

